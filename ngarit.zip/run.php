<?php
/** 
	Author : Olly Was Here (@ardyjoo)
**/
require "./lib.php";
$reff = "9O525MO8M"; // REFF
$serverMail = 1; // Server Generate Mail select 1 or 0
echo "[!] PENAK TINGGAL TURU..\n";
echo "[!] AMIKOM SANTUY\n";
echo "[!] STARTED... GENERATING MAIL\n";
if($serverMail == 1){
	require "./gen.php";
	include("./v2.php");
}else{
	require "./temp.php";
	include("./v1.php");
}
?>
