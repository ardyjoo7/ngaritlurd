<?php
require "./temp.php";
$reff = "9O525MO8M";
echo ">>>> : "; $mail = trim(fgets(STDIN));
echo RegisterBigToken($mail, $reff);
?>